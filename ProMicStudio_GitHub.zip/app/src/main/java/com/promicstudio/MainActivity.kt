package com.promicstudio

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import android.graphics.Typeface
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : Activity() {
    private val bg = Color.rgb(8, 12, 20)
    private val panel = Color.rgb(18, 26, 39)
    private val blue = Color.rgb(48, 150, 255)
    private lateinit var engine: MicEngine
    private var player: MediaPlayer? = null
    private lateinit var status: TextView
    private lateinit var startButton: Button
    private lateinit var gainLabel: TextView
    private lateinit var gateLabel: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        engine = MicEngine(this)
        buildUi()
    }

    private fun buildUi() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(28))
        }
        scroll.addView(root)
        setContentView(scroll)

        val brand = TextView(this).apply {
            text = "PRO MIC STUDIO"
            textSize = 24f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
            letterSpacing = .08f
        }
        root.addView(brand)
        root.addView(label("ULTRA AUDIO  •  LIVE MICROPHONE", 12, blue))
        root.addView(space(18))

        val statusCard = card()
        status = label("●  الميكروفون متوقف", 16, Color.LTGRAY)
        statusCard.addView(status)
        root.addView(statusCard)
        root.addView(space(14))

        startButton = button("تشغيل الميكروفون")
        startButton.setOnClickListener {
            if (engine.isRunning) {
                engine.stop()
                startButton.text = "تشغيل الميكروفون"
                status.text = "●  الميكروفون متوقف"
                status.setTextColor(Color.LTGRAY)
            } else {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                    != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 77)
                } else startMic()
            }
        }
        root.addView(startButton, matchWrap())

        root.addView(space(18))
        root.addView(label("معالجة الصوت", 19, Color.WHITE))
        root.addView(space(8))

        val gainCard = card()
        gainLabel = label("قوة الميكروفون: 100%", 14, Color.WHITE)
        gainCard.addView(gainLabel)
        val gain = SeekBar(this).apply {
            max = 200; progress = 100
            setOnSeekBarChangeListener(listener { v ->
                engine.gain = v / 100f
                gainLabel.text = "قوة الميكروفون: $v%"
            })
        }
        gainCard.addView(gain)
        root.addView(gainCard)

        val gateCard = card()
        gateLabel = label("بوابة الضوضاء: 35%", 14, Color.WHITE)
        gateCard.addView(gateLabel)
        val gate = SeekBar(this).apply {
            max = 100; progress = 35
            setOnSeekBarChangeListener(listener { v ->
                engine.gate = v / 100f * 0.035f
                gateLabel.text = "بوابة الضوضاء: $v%"
            })
        }
        gateCard.addView(gate)
        root.addView(gateCard)

        root.addView(space(18))
        root.addView(label("الموسيقى والمؤثرات", 19, Color.WHITE))
        root.addView(space(8))
        val musicCard = card()
        musicCard.addView(label("اختر ملفاً صوتياً لتشغيله على جهازك بالتوازي مع مراقبة الميكروفون.", 13, Color.LTGRAY))
        val choose = button("اختيار ملف موسيقى")
        choose.setOnClickListener {
            val intent = android.content.Intent(android.content.Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(android.content.Intent.CATEGORY_OPENABLE)
                type = "audio/*"
            }
            startActivityForResult(intent, 88)
        }
        musicCard.addView(choose, matchWrap())
        val musicControls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        val play = button("تشغيل")
        play.setOnClickListener { try { player?.start() } catch (_: Exception) { toast("اختر ملفاً صوتياً أولاً") } }
        val pause = button("إيقاف مؤقت")
        pause.setOnClickListener { player?.pause() }
        musicControls.addView(play, LinearLayout.LayoutParams(0, dp(48), 1f))
        musicControls.addView(pause, LinearLayout.LayoutParams(0, dp(48), 1f))
        musicCard.addView(musicControls)
        root.addView(musicCard)

        root.addView(space(16))
        val note = label(
            "تنبيه توافق Android: تشغيل الموسيقى هنا يخرج إلى سماعة/سماعات الهاتف ولا يحقنها داخل مدخل الميكروفون لتطبيقات PUBG أو WhatsApp. توجيه الصوت إلى مكالمة أو لعبة يحتاج دعماً من النظام أو جهاز مزج صوتي خارجي متوافق. استخدم سماعات الرأس لتجنب الصدى.",
            12, Color.rgb(190, 200, 215)
        )
        val noteCard = card(); noteCard.addView(note); root.addView(noteCard)
        root.addView(space(12))
        root.addView(label("المعالجة تعتمد على إمكانات جهازك. لا يوجد تطبيق Android عادي يستطيع ضمان تجاوز عزل الميكروفون بين التطبيقات.", 11, Color.GRAY))
    }

    private fun startMic() {
        try {
            engine.start()
            startButton.text = "إيقاف الميكروفون"
            status.text = "●  الميكروفون يعمل — استخدم سماعات الرأس"
            status.setTextColor(Color.rgb(65, 220, 145))
        } catch (e: Exception) {
            toast("تعذر تشغيل الميكروفون: ${e.message ?: "تحقق من الصلاحيات"}")
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, results)
        if (requestCode == 77 && results.isNotEmpty() && results[0] == PackageManager.PERMISSION_GRANTED) startMic()
        else if (requestCode == 77) toast("يلزم السماح باستخدام الميكروفون")
    }

    @Deprecated("Legacy activity result for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: android.content.Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 88 && resultCode == RESULT_OK) {
            val uri: Uri = data?.data ?: return
            try {
                player?.release()
                player = MediaPlayer().apply {
                    setDataSource(this@MainActivity, uri)
                    setOnPreparedListener { toast("الموسيقى جاهزة للتشغيل") }
                    setOnErrorListener { _, _, _ -> toast("تعذر تشغيل هذا الملف"); true }
                    prepareAsync()
                }
            } catch (_: Exception) { toast("تعذر فتح الملف الصوتي") }
        }
    }

    override fun onDestroy() {
        engine.stop()
        player?.release()
        player = null
        super.onDestroy()
    }

    private fun listener(action: (Int) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) { action(progress) }
        override fun onStartTrackingTouch(seekBar: SeekBar?) {}
        override fun onStopTrackingTouch(seekBar: SeekBar?) {}
    }
    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(14), dp(12), dp(14), dp(12))
        setBackgroundColor(panel)
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            setMargins(0, dp(5), 0, dp(5))
        }
    }
    private fun label(s: String, size: Int, color: Int) = TextView(this).apply {
        text = s; textSize = size.toFloat(); setTextColor(color); setPadding(0, dp(4), 0, dp(4))
    }
    private fun button(s: String) = Button(this).apply {
        text = s; setTextColor(Color.WHITE); setBackgroundColor(blue); textSize = 14f
    }
    private fun space(h: Int) = android.view.View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(h)) }
    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)).apply { topMargin = dp(6) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
