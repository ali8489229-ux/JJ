package com.promicstudio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.AutomaticGainControl
import android.media.audiofx.NoiseSuppressor
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Foreground live monitor prototype.
 * Processing chain: platform NS/AGC/AEC (when available), soft noise gate,
 * input gain and peak limiter. Output is local monitoring, NOT a virtual mic.
 */
class MicEngine(private val context: Context) {
    @Volatile var isRunning = false
        private set
    @Volatile var gain: Float = 1f
    @Volatile var gate: Float = 0.012f

    private var recorder: AudioRecord? = null
    private var track: AudioTrack? = null
    private var worker: Thread? = null
    private var ns: NoiseSuppressor? = null
    private var agc: AutomaticGainControl? = null
    private var aec: AcousticEchoCanceler? = null

    fun start() {
        if (isRunning) return
        val rate = 48000
        val minIn = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val minOut = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        require(minIn > 0 && minOut > 0) { "الجهاز لا يدعم إعداد الصوت المطلوب" }
        val buffer = max(minIn, minOut) * 2
        val input = AudioRecord(
            MediaRecorder.AudioSource.VOICE_RECOGNITION,
            rate,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
            buffer
        )
        require(input.state == AudioRecord.STATE_INITIALIZED) { "تعذر تهيئة تسجيل الصوت" }
        val output = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setSampleRate(rate).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(buffer)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        recorder = input
        track = output

        val session = input.audioSessionId
        if (NoiseSuppressor.isAvailable()) ns = NoiseSuppressor.create(session)?.apply { enabled = true }
        if (AutomaticGainControl.isAvailable()) agc = AutomaticGainControl.create(session)?.apply { enabled = true }
        if (AcousticEchoCanceler.isAvailable()) aec = AcousticEchoCanceler.create(session)?.apply { enabled = true }

        input.startRecording()
        output.play()
        isRunning = true
        worker = Thread {
            val samples = ShortArray(buffer / 2)
            var prevIn = 0f
            var prevOut = 0f
            while (isRunning) {
                val count = try { input.read(samples, 0, samples.size) } catch (_: Exception) { -1 }
                if (count < 0) break
                if (count == 0) continue
                val localGain = gain
                val threshold = gate
                for (i in 0 until count) {
                    var x = samples[i].toFloat() / 32768f
                    // Gentle DC/high-pass cleanup.
                    val y = x - prevIn + 0.995f * prevOut
                    prevIn = x
                    prevOut = y
                    x = y
                    // Soft gate with a small fade instead of a hard cutoff.
                    val magnitude = abs(x)
                    if (magnitude < threshold) x *= magnitude / max(threshold, 0.0001f)
                    x *= localGain
                    // Soft limiter to reduce harsh clipping.
                    x = when {
                        x > 0.92f -> 0.92f + (x - 0.92f) * 0.12f
                        x < -0.92f -> -0.92f + (x + 0.92f) * 0.12f
                        else -> x
                    }
                    samples[i] = (x.coerceIn(-1f, 1f) * 32767f).toInt().toShort()
                }
                try { output.write(samples, 0, count) } catch (_: Exception) { break }
            }
        }.apply { name = "ProMicAudio"; start() }
    }

    fun stop() {
        if (!isRunning && recorder == null) return
        isRunning = false
        try { worker?.join(500) } catch (_: InterruptedException) {}
        worker = null
        try { recorder?.stop() } catch (_: Exception) {}
        try { track?.pause(); track?.flush(); track?.stop() } catch (_: Exception) {}
        recorder?.release(); recorder = null
        track?.release(); track = null
        ns?.release(); ns = null
        agc?.release(); agc = null
        aec?.release(); aec = null
    }
}
